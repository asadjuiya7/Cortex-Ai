# Asfar — Native Android App (real background wake word)

Ye ek **native Android Studio project** hai. Isse browser/PWA wala limitation khatam ho jata hai:
ab "Hey Asfar" **background mein bhi** kaam karega — screen band ho, app minimize ho, phir bhi sunega
(ek foreground service ke through, jaisa asal apps karte hain).

**Kya hai andar:**
- `MainActivity.kt` — humara poora web app (Dashboard/Agents/World/Settings) ek WebView mein load karta hai
  (`assets/www/` — same bundled build jo mobile browser version mein use hoti hai)
- `WakeWordService.kt` — background mein hamesha "Hey Asfar" sunta rehta hai (persistent notification ke sath)
- Jab wake word suno jaye, app khud khul jati hai aur command web app ko de di jati hai

## Zaroori cheezein (pehli baar setup)

**Do tareeqe hain — koi bhi ek chuno:**

### Option A: GitHub Actions (Android Studio install NAHI karni — free, cloud mein build hota hai)

1. **github.com** par free account banao (agar nahi hai)
2. Naya **repository** banao (Public ya Private, koi farq nahi) — naam kuch bhi rakho, jaise `asfar-android`
3. Is `AsfarAndroid` folder ka **pura content** us repo mein upload karo:
   - Sabse aasan: GitHub repo page par **"uploading an existing file"** link se, is zip ko **extract karke saari files/folders drag-drop** kar do (`.github` folder bhi zaroor shamil ho — ye hi build karta hai)
   - Ya agar `git` pata hai: `git init`, `git add .`, `git commit -m "asfar android"`, `git remote add origin <repo-url>`, `git push`
4. Upload hote hi GitHub khud build shuru kar dega. Repo ke **"Actions"** tab mein jao, chalti hui build dikhegi (~3-5 min lagte hain)
5. Build **green tick ✓** ho jaye to us run ko open karo, neeche **"Artifacts"** section mein **`asfar-debug-apk`** milega — download karo, andar `.apk` hogi
6. Wo `.apk` phone mein transfer karo, tap karo, install karo ("Install anyway" allow karna pad sakta hai)

Ye poora process **bina Android Studio ke** hota hai — sirf GitHub ka free account chahiye.

### Option B: Android Studio (local build, zyada control)

1. **Android Studio** install karo: https://developer.android.com/studio (free hai)
2. Isi `AsfarAndroid` folder ko Android Studio mein **"Open"** karo (File → Open → is folder ko select karo)
3. Android Studio khud **Gradle sync** karega (internet chahiye hoga, pehli baar 5-10 min lag sakta hai — SDK/dependencies download hoti hain)
4. Agar koi missing SDK component ka popup aaye, **"Install"** dabate jao

## Chalane ka tareeqa

1. Phone ko USB se connect karo, **Developer Options → USB Debugging** ON karo
   (Settings → About Phone → "Build Number" 7 baar tap karo, phir Developer Options mil jayega)
2. Android Studio mein upar **green ▶ Run button** dabao, apna phone select karo
3. App install ho kar khul jayegi

**Ya .apk banao (bina cable ke install karne ke liye):**
- Android Studio mein: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
- `app/build/outputs/apk/debug/app-debug.apk` mil jayegi — ye phone mein transfer kar ke install kar sakte ho

## Permissions (pehli baar app kholne par)

- **Microphone** — allow karo (wake word ke liye zaroori)
- **Notifications** — allow karo (background service ka "Asfar is listening" notification dikhane ke liye)
- **Battery optimization** — Settings → Apps → Asfar → Battery → **"Unrestricted"** kar do, warna Android
  kuch der baad background service ko khud band kar dega (ye Android ki apni power-saving policy hai, har app
  ke sath hoti hai jo background mein kaam karti hai — WhatsApp, Gmail wagera bhi yehi setting maangte hain)

## Use karna

1. App mein Settings (⚙) kholo, API key waghera wahi jo mobile-web version mein dalte the
2. **Wake word** toggle ON karo — ab ye native background service ko start kar dega (browser wala tareeqa
   nahi, seedha Android level par)
3. App band/minimize kar do, phone kahin bhi rakho — **"Hey Asfar"** bolo
4. App khud khul jayegi, agar sath hi command bhi bola tha (jaise "Hey Asfar, wifi on karo") to seedha
   process ho jayega; sirf "Hey Asfar" bola to mic khud khul jayega agle command ke liye

## Honest limitations

- **Battery**: hamesha background mic sunna battery use karta hai. Agar zyada drain lage, wake word Settings
  se OFF kar do jab zaroorat na ho.
- **Android battery-saver / Doze mode**: bohat aggressive battery savers (kuch Xiaomi/Oppo/Vivo phones)
  background services ko zabardasti band kar dete hain chahe "Unrestricted" set ho. Us phone-brand ki
  "autostart" / "background activity" setting bhi alag se allow karni pad sakti hai.
- **Pehli build mein chhoti dikkatein aa sakti hain** — main isko yahan se compile/test nahi kar saka
  (Android SDK is sandbox mein available nahi hai), isliye agar Android Studio koi error dikhaye, wo error
  message mujhe bata dena, turant fix kar dunga.
- Web app ke UI updates (Dashboard design, naye features) ke liye `assets/www/` folder ko dobara build
  karke replace karna hoga — agar future mein web version update ho, mujhse naya `assets/www/` bundle
  maang lena.

## Agar kuch error aaye

Android Studio ke neeche **"Build"** tab mein jo bhi error message aaye, uska screenshot ya text yahan
paste kar dena — us hisab se code fix kar dunga.
